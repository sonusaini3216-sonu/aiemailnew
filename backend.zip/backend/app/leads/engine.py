def lead_engine(keyword):
    return [{"company": "Demo Co", "email": "demo@example.com"}]
