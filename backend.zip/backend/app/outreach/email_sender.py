def send_email(to, subject, body):
    print("Sending email to", to)
    return True
