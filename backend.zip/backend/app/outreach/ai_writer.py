def generate_email(name, company):
    return f"Hi {name},\n\nI have an idea for {company}..."
