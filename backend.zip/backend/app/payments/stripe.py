def create_session():
    return {"url": "https://stripe.com"}
