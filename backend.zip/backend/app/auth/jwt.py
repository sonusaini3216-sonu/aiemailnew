from jose import jwt
from datetime import datetime, timedelta

SECRET = "CHANGE_ME"

def create_token(user_id):
    return jwt.encode({
        "user_id": user_id,
        "exp": datetime.utcnow() + timedelta(days=7)
    }, SECRET, algorithm="HS256")
